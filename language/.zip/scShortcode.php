<?php
 // no direct access
defined('_JEXEC') or die('Restricted access');
jimport('joomla.plugin.plugin'); 

class plgSystemscShortcode extends JPlugin
{

	public function __construct(&$subject, $config){
		parent::__construct($subject, $config);
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function onAfterRender()
	{
		$this->ButtonShortcodes();  //add shortcode to editor
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
    protected $autoloadLanguage = true ;	
	function onContentPrepare($context, $article, $params, $limitstart)
        {   
           // check user type 	
           $user = JFactory::getUser();
         if ($user->guest) // user not login
            {
             $newurl = "<a href='#' target='_blank'>لطفا برای دیدن محتوا ثبت نام کنید</a>";
             $pattern = '/\[SC\](.*?)\[\/SC\]/s';
             $article->text=  preg_replace($pattern,$newurl,$article->text);    
    
             return true;
            }     
        
         else // user login
            {	
             $patterns = array();
             $patterns[0] = '/\[SC\]/';
             $patterns[1] = '/\[\/SC\]/';
             $replacements = array();
             $replacements[0] = '';
             $replacements[1] = '';
             $article->text=  preg_replace($patterns,$replacements,$article->text);

             return true;
	        }        
        
        }	
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function ButtonShortcodes()
	{
		$Scpage   = JResponse::GetBody();
		$btn = $this->valueShortcode();
		$sSTR  = '<script  type="text/javascript">		        
						function getInputUser(msg) {    
							txt = prompt(msg);
			                if (!txt) 
			                {
			                return;
						    }
						    else
						    {
						     STR="<br/><br/>[SC]<br/>"+txt+"<br/>[/SC]<br/>";
						    }
							STR = STR.replace(/\'/g, \'"\');

							if(document.getElementById(\'jform_articletext\') != null) {
								jInsertEditorText(STR, \'jform_articletext\');
								
							}				
						}
				   </script>';
		$Scpage = str_replace('<div id="editor-xtd-buttons">', '<div id="editor-xtd-buttons">' . $btn, $Scpage);
		$Scpage = str_replace('<div id="editor-xtd-buttons" class="btn-toolbar pull-left">', '<div id="editor-xtd-buttons" class="btn-toolbar pull-left">' . $btn, $Scpage);
		$Scpage = str_replace('</body>', $sSTR . '</body>', $Scpage);
		JResponse::SetBody($Scpage);
	}
	/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	public function valueShortcode()
	{
		$linksc = array('name'		=> "Link",'tooltip'		=> "لینک");		
		$STR  = '';
		$msg='لینک مورد نظر را وارد کنید';
		$STR .= '<a class="jomjome" href="javascript: void(0);" onclick="getInputUser(\''.$msg.'\')" title="' . $linksc['tooltip'] . '">'; 
		$STR .='<div>';
		$STR .='<span class="btn">اضافه کردن شرتکد</span>';
	    $STR .= '</a>';
		$STR .= '</li>';
		$STR .='</div>';
		
		return $STR; 
		
	}
}
